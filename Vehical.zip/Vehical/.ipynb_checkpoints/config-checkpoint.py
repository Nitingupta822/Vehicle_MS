# config.py
DATABASE_URL = "postgresql://user_info_4gfk_user:Hv2nshMamC3p7C1sU9dNVJMJHrNikSmA@dpg-d0o1ltmuk2gs73fk4tmg-a.oregon-postgres.render.com/user_info_4gfk"
SECRET_KEY = "dev_key"
